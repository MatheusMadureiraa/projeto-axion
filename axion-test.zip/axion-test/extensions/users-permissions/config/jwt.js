module.exports = {
  jwtSecret: process.env.JWT_SECRET || '0e3b9387-0de2-4b74-b406-7eb5edcf869c'
};